package Mode;

public interface Print {
    public void printData(String data);
}
