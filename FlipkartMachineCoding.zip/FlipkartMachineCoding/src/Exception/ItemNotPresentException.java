package Exception;

public class ItemNotPresentException extends RuntimeException{
    public ItemNotPresentException(String message) {
        super(message);
    }
}
