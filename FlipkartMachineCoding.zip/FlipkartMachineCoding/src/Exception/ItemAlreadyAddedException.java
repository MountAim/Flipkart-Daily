package Exception;

public class ItemAlreadyAddedException extends RuntimeException {
    public ItemAlreadyAddedException(String message) {
        super(message);
    }
}
