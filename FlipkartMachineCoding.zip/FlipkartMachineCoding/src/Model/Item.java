package Model;

public class Item {
    private final String brand;
    private final String category;
    private final int price;
    private int quantity;

    public Item(String brand, String category, int price) {
        this.brand = brand;
        this.category = category;
        this.price = price;
        this.quantity = 0;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getBrand() { return brand; }
    public String getCategory() { return category; }
    public int getPrice() { return price; }
    public int getQuantity() { return quantity; }

    public void addQuantity(int qty) { this.quantity += qty; }

}
