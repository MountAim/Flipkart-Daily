package Database;

import Mode.ConsolePrint;
import Mode.Print;
import Model.Item;

import java.util.HashMap;
import java.util.Map;
import java.util.AbstractMap.SimpleEntry;

import Exception.*;

public class InventoryRepository {
    Print print = new ConsolePrint();
    private Map<SimpleEntry<String, String>, Item> inventory = new HashMap<>();

    public void addItem(String brand, String category, int price) {
        SimpleEntry<String, String> key = new SimpleEntry<>(brand, category);
        if(inventory.containsKey(key)){
            throw new ItemAlreadyAddedException("Already added the item");
        }
        inventory.put(key, new Item(brand, category, price));
        print.printData("Item added successfully");
    }

    public void addInventory(String brand, String category, int quantity) {
        SimpleEntry<String, String> key = new SimpleEntry<>(brand, category);
        if (inventory.containsKey(key)) {
            inventory.get(key).addQuantity(quantity);
            print.printData("Inventory added successfully");
        }
        else{
            throw new ItemNotPresentException("Item is not added in Inventory");
        }
    }

    public Map<SimpleEntry<String, String>, Item> getInventory() {
        return inventory;
    }

    public void setInventory(Map<SimpleEntry<String, String>, Item> inventory) {
        this.inventory = inventory;
    }
}
