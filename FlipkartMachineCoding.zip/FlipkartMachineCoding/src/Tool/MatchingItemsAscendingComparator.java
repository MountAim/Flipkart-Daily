package Tool;
import Model.Item;

import java.util.Comparator;

public class MatchingItemsAscendingComparator implements Comparator<Item> {
    @Override
    public int compare(Item item1, Item item2) {
        return Integer.compare(item1.getPrice(), item2.getPrice());
    }
}
