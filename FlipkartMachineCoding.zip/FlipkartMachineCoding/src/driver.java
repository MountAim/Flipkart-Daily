import Database.InventoryRepository;
import Mode.ConsolePrint;
import Mode.Print;
import Model.Item;
import Service.*;

import java.util.*;

public class driver {
    public static void main(String[] args) {

//        Add Item (brand, category, price)
//        Add inventory (brand, category, quantity)
//        SearchItems(“category”=[“categoryValue”]) / SearchItems(“brand”=[“brandValue”]) / SearchItems(“price”=[fromPrice, toPrice])
//        SearchItems(“category”=[“categoryValue”], Order_By=[Price, asc]) / SearchItems(“category”=[“categoryValue”], Order_By=[ItemQty, desc])
        Print print = new ConsolePrint();
        InventoryRepository inventoryRepository = new InventoryRepository();
        InventoryService inventoryService = new InventoryService(inventoryRepository);
        SearchCriteriaService brandCriteriaService = new BrandCriteriaService(inventoryRepository);
        SearchCriteriaService categoryCriteriaService = new CategoryCriteriaService(inventoryRepository);
        SearchCriteriaService priceRangeCriteriaService = new PriceRangeCriteriaService(inventoryRepository);
        SortService descendingSortService = new DescendingSortService();
        SortService ascendingSortService = new AscendingSortService();
        SortService quantityBasedSortingService = new QuantityBasedSortingService();

        // Adding items
        inventoryService.addItem("Amul", "Milk", 100);
        inventoryService.addItem("Amul", "Curd", 50);
        inventoryService.addItem("Nestle", "Milk", 60);
        inventoryService.addItem("Nestle", "Curd", 90);

        // Adding inventory
        inventoryService.addInventory("Amul", "Milk", 20);
        inventoryService.addInventory("Amul", "Curd", 5);
        inventoryService.addInventory("Nestle", "Milk", 15);
        inventoryService.addInventory("Nestle", "Curd", 10);

        List<Item> items = brandCriteriaService.searchItemWithCriteria("Nestle");

        for(Item item: items){
            print.printData(item.getCategory() + item.getBrand() + item.getPrice() + item.getQuantity());
        }

        items = categoryCriteriaService.searchItemWithCriteria("Milk");
        descendingSortService.sortByFilter(items);

        for(Item item: items){
            print.printData(item.getCategory() + item.getBrand() + item.getPrice() + item.getQuantity());
        }

        items = priceRangeCriteriaService.searchItemWithCriteria("90-");
        quantityBasedSortingService.sortByFilter(items);

        for(Item item: items){
            print.printData(item.getCategory() + item.getBrand() + item.getPrice() + item.getQuantity());
        }

    }
}



