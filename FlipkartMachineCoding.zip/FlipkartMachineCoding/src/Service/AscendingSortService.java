package Service;

import Model.Item;
import Tool.*;
import java.util.Collections;
import java.util.List;


public class AscendingSortService implements SortService {
    public List<Item> sortByFilter(List<Item> items){
        Collections.sort(items, new MatchingItemsAscendingComparator());
        return items;
    }
}
