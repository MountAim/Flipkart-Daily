package Service;

import Model.Item;

import java.util.List;

public interface SortService {
    public List<Item> sortByFilter(List<Item> items);
}
