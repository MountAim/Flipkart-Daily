package Service;

import Model.Item;

import java.util.List;

public interface SearchCriteriaService {
    List<Item> searchItemWithCriteria(String criteria);
}
