package Service;

import Database.InventoryRepository;
import Model.Item;

import java.util.*;
import Tool.*;

public class BrandCriteriaService implements SearchCriteriaService {
    InventoryRepository inventoryRepository;

    public BrandCriteriaService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    public List<Item> searchItemWithCriteria(String criteria){
        List<Item> matchingItems = new ArrayList<>();

        // Iterate over the inventory items
        for (Map.Entry<AbstractMap.SimpleEntry<String, String>, Item> entry : inventoryRepository.getInventory().entrySet()) {
            String itemBrand = entry.getKey().getKey(); // brand is stored in key pair's first part
            Item item = entry.getValue();
            if (itemBrand == criteria) {
                matchingItems.add(item);
            }
        }
        Collections.sort(matchingItems, new MatchingItemsAscendingComparator());
        return matchingItems;
    }
}
