package Service;

import Database.InventoryRepository;
import Model.Item;

import java.util.*;
import Tool.*;

public class PriceRangeCriteriaService implements SearchCriteriaService{
    InventoryRepository inventoryRepository;
    int INF = 10000000;

    public PriceRangeCriteriaService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    public List<Item> searchItemWithCriteria(String criteria){
        String[] parts = criteria.split("\\-");

        Integer minPrice, maxPrice;
        if(parts[0]!="")
            minPrice = Integer.parseInt(parts[0]);
        else minPrice = 0;
        if(parts.length > 1)
            maxPrice = Integer.parseInt(parts[1]);
        else maxPrice = INF;

        List<Item> matchingItems = new ArrayList<>();

        // Iterate over the inventory items
        for (Map.Entry<AbstractMap.SimpleEntry<String, String>, Item> entry : inventoryRepository.getInventory().entrySet()) {
            Integer itemPrice = entry.getValue().getPrice(); // brand is stored in key pair's first part
            Item item = entry.getValue();
            if (itemPrice >= minPrice && itemPrice <= maxPrice) {
                matchingItems.add(item);
            }
        }
        Collections.sort(matchingItems, new MatchingItemsAscendingComparator());
        return matchingItems;
    }
}
