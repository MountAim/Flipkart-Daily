package Service;

import Database.InventoryRepository;
import Mode.ConsolePrint;
import Mode.Print;


public class InventoryService {
    Print print = new ConsolePrint();
    InventoryRepository inventoryRepository;

    public InventoryService(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    public void addItem(String brand, String category, int price) {
        inventoryRepository.addItem(brand, category, price);
    }

    public void addInventory(String brand, String category, int quantity) {
        inventoryRepository.addInventory(brand, category, quantity);
    }

}
