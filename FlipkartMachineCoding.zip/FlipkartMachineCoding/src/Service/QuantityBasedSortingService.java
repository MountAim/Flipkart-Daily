package Service;

import Model.Item;
import Tool.*;
import java.util.Collections;
import java.util.List;


public class QuantityBasedSortingService implements SortService {
    public List<Item> sortByFilter(List<Item> items){
        Collections.sort(items, new MatchingItemsQuantityComparator());
        return items;
    }
}
